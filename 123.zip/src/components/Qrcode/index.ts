import Qrcode from './src/Qrcode.vue'

export { Qrcode }
