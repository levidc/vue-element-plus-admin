import Logo from './src/Logo.vue'

export { Logo }
