import Dialog from './src/Dialog.vue'

export { Dialog }
