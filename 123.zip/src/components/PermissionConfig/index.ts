import PermissionConfig from './src/PermissionConfig.vue'

export { PermissionConfig }
