import TabMenu from './src/TabMenu.vue'

export { TabMenu }
