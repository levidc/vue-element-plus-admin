import RestfulList from './src/RestfulList.vue'
import RestfulEdit from './src/RestfulEdit.vue'

export { RestfulList, RestfulEdit }
