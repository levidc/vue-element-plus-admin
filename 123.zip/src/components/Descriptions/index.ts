import Descriptions from './src/Descriptions.vue'

export { Descriptions }
