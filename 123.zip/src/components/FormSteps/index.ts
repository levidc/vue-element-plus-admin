import FormSteps from './src/FormSteps.vue'

export { FormSteps }
