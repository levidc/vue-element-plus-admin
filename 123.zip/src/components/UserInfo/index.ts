import UserInfo from './src/UserInfo.vue'

export { UserInfo }
