import Infotip from './src/Infotip.vue'

export { Infotip }
