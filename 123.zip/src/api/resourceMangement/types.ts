export type testType = {
  username: string
  password: string
}
