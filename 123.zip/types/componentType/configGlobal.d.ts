declare interface ConfigGlobalTypes {
  size?: ElememtPlusSize
}
