declare interface QrcodeLogo {
  src?: string
  logoSize?: number
  bgColor?: string
  borderSize?: number
  crossOrigin?: string
  borderRadius?: number
  logoRadius?: number
}
