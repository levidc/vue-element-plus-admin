var p = {
    id: 123,
    str: '123'
};
var key = p.id;
console.log(key);
